package com.example.guia11_formularios_validaciones.ui.solicitud

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.guia11_formularios_validaciones.viewmodel.SolicitudViewModel
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SolicitudFormScreen(
    navController: NavController,
    viewModel: SolicitudViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val isEditing by viewModel.isEditing.collectAsState()
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val categorias = listOf("Infraestructura", "Soporte Técnico", "Limpieza", "Seguridad", "Otros")
    var expanded by remember { mutableStateOf(false) }

    var capturedBitmap by remember(uiState.evidenciaUri) { 
        mutableStateOf<Bitmap?>(
            uiState.evidenciaUri?.let { path ->
                try {
                    val file = File(path)
                    if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
                } catch (e: Exception) { null }
            }
        ) 
    }
    
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            capturedBitmap = bitmap
            try {
                val file = File(context.filesDir, "evidencia_${System.currentTimeMillis()}.jpg")
                val fos = FileOutputStream(file)
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
                fos.flush()
                fos.close()
                viewModel.onEvidenciaUriChanged(file.absolutePath)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch(null)
        } else {
            Toast.makeText(context, "Se requiere permiso de cámara", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Editar Solicitud" else "Nueva Solicitud") },
                navigationIcon = {
                    IconButton(onClick = { 
                        viewModel.resetForm()
                        if (!navController.popBackStack()) {
                            navController.navigate("lista_solicitudes")
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    IconButton(onClick = { navController.navigate("lista_solicitudes") }) {
                        Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Ver Lista")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Titulo
            ErrorAnimatedTextField(
                value = uiState.titulo,
                onValueChange = { viewModel.onTituloChanged(it) },
                label = "Título *",
                error = uiState.tituloError
            )

            // Descripción
            ErrorAnimatedTextField(
                value = uiState.descripcion,
                onValueChange = { viewModel.onDescripcionChanged(it) },
                label = "Descripción *",
                error = uiState.descripcionError,
                supportingText = "(mínimo 10 caracteres)",
                minLines = 3
            )

            // Categoría
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = uiState.categoria,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Categoría *") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
                    isError = uiState.categoriaError != null,
                    supportingText = {
                        AnimatedVisibility(visible = uiState.categoriaError != null) {
                            uiState.categoriaError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        }
                    }
                )
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    categorias.forEach { categoria ->
                        DropdownMenuItem(
                            text = { Text(categoria) },
                            onClick = {
                                viewModel.onCategoriaChanged(categoria)
                                expanded = false
                            }
                        )
                    }
                }
            }

            // Servicio
            ErrorAnimatedTextField(
                value = uiState.servicio,
                onValueChange = { viewModel.onServicioChanged(it) },
                label = "Servicio *",
                error = uiState.servicioError
            )

            // Foto
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Evidencia Fotográfica", style = MaterialTheme.typography.titleSmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    AnimatedVisibility(
                        visible = capturedBitmap != null,
                        enter = fadeIn() + expandVertically()
                    ) {
                        capturedBitmap?.let {
                            Image(
                                bitmap = it.asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier.fillMaxWidth().height(180.dp)
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                cameraLauncher.launch(null)
                            } else {
                                permissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                        }
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (capturedBitmap == null) "Tomar Foto" else "Cambiar Foto")
                    }
                }
            }

            Button(
                onClick = {
                    viewModel.validarYGuardar {
                        Toast.makeText(context, "Operación exitosa", Toast.LENGTH_SHORT).show()
                        navController.popBackStack()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                enabled = !uiState.guardando
            ) {
                Text(if (isEditing) "Actualizar Solicitud" else "Guardar Solicitud")
            }
        }
    }
}

@Composable
fun ErrorAnimatedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    error: String?,
    supportingText: String = "",
    minLines: Int = 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        isError = error != null,
        minLines = minLines,
        singleLine = minLines == 1,
        supportingText = {
            Column {
                AnimatedVisibility(
                    visible = error != null,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
                if (supportingText.isNotEmpty() && error == null) {
                    Text(supportingText)
                }
            }
        }
    )
}
