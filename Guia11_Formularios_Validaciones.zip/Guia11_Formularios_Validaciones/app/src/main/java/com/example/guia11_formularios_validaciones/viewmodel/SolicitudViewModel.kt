package com.example.guia11_formularios_validaciones.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.guia11_formularios_validaciones.model.SolicitudUiState
import com.example.guia11_formularios_validaciones.model.data.local.AppDatabase
import com.example.guia11_formularios_validaciones.model.data.local.SolicitudEntity
import com.example.guia11_formularios_validaciones.model.data.repository.SolicitudRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SolicitudViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: SolicitudRepository

    init {
        val dao = AppDatabase.getDatabase(application).solicitudDao()
        repository = SolicitudRepository(dao)
    }

    val listaSolicitudes: StateFlow<List<SolicitudEntity>> = repository.listaSolicitudes
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _uiState = MutableStateFlow(SolicitudUiState())
    val uiState: StateFlow<SolicitudUiState> = _uiState.asStateFlow()

    private val _solicitudSeleccionada = MutableStateFlow<SolicitudEntity?>(null)
    val solicitudSeleccionada: StateFlow<SolicitudEntity?> = _solicitudSeleccionada.asStateFlow()

    private val _isEditing = MutableStateFlow(false)
    val isEditing: StateFlow<Boolean> = _isEditing.asStateFlow()

    private val _isProcessingQr = MutableStateFlow(false)
    val isProcessingQr: StateFlow<Boolean> = _isProcessingQr.asStateFlow()

    private var idEdicion: Long? = null

    fun seleccionarSolicitud(solicitud: SolicitudEntity?) {
        _solicitudSeleccionada.value = solicitud
    }

    fun buscarPorCodigo(codigo: String, onEncontrada: (SolicitudEntity) -> Unit, onNoEncontrada: () -> Unit) {
        if (_isProcessingQr.value) return
        
        viewModelScope.launch {
            _isProcessingQr.value = true
            val encontrada = repository.obtenerPorCodigo(codigo)
            if (encontrada != null) {
                seleccionarSolicitud(encontrada)
                onEncontrada(encontrada)
            } else {
                onNoEncontrada()
            }
            _isProcessingQr.value = false
        }
    }

    fun prepararEdicion(solicitud: SolicitudEntity) {
        idEdicion = solicitud.id
        _isEditing.value = true
        _uiState.update {
            it.copy(
                titulo = solicitud.titulo,
                descripcion = solicitud.descripcion,
                categoria = solicitud.categoria,
                servicio = solicitud.servicio,
                evidenciaUri = solicitud.evidenciaUri,
                tituloError = null,
                descripcionError = null,
                categoriaError = null,
                servicioError = null
            )
        }
    }

    fun onTituloChanged(titulo: String) {
        _uiState.update {
            it.copy(
                titulo = titulo,
                tituloError = if (titulo.isBlank()) "El título es obligatorio" else null
            )
        }
    }

    fun onDescripcionChanged(descripcion: String) {
        val error = when {
            descripcion.isBlank() -> "La descripción es obligatoria"
            descripcion.length < 10 -> "Debe tener al menos 10 caracteres"
            else -> null
        }
        _uiState.update {
            it.copy(
                descripcion = descripcion,
                descripcionError = error
            )
        }
    }

    fun onCategoriaChanged(categoria: String) {
        _uiState.update {
            it.copy(
                categoria = categoria,
                categoriaError = if (categoria.isBlank()) "La categoría es obligatoria" else null
            )
        }
    }

    fun onServicioChanged(servicio: String) {
        _uiState.update {
            it.copy(
                servicio = servicio,
                servicioError = if (servicio.isBlank()) "El servicio relacionado es obligatorio" else null
            )
        }
    }

    fun onEvidenciaUriChanged(uri: String?) {
        _uiState.update { it.copy(evidenciaUri = uri) }
    }

    fun validarYGuardar(onSuccess: () -> Unit) {
        val current = _uiState.value
        val tituloErr = if (current.titulo.isBlank()) "El título es obligatorio" else null
        val descErr = when {
            current.descripcion.isBlank() -> "La descripción es obligatoria"
            current.descripcion.length < 10 -> "Debe tener al menos 10 caracteres"
            else -> null
        }
        val catErr = if (current.categoria.isBlank()) "La categoría es obligatoria" else null
        val servErr = if (current.servicio.isBlank()) "El servicio relacionado es obligatorio" else null

        if (tituloErr != null || descErr != null || catErr != null || servErr != null) {
            _uiState.update {
                it.copy(
                    tituloError = tituloErr,
                    descripcionError = descErr,
                    categoriaError = catErr,
                    servicioError = servErr
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(guardando = true) }
            val fechaActual = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

            if (idEdicion == null) {
                val codigoUnico = "SOL-${System.currentTimeMillis().toString().takeLast(6)}"
                val nuevaSolicitud = SolicitudEntity(
                    codigo = codigoUnico,
                    titulo = current.titulo,
                    descripcion = current.descripcion,
                    categoria = current.categoria,
                    servicio = current.servicio,
                    evidenciaUri = current.evidenciaUri,
                    estado = "Recibida",
                    fechaHora = fechaActual
                )
                repository.insertar(nuevaSolicitud)
            } else {
                val existente = _solicitudSeleccionada.value
                if (existente != null) {
                    val actualizada = existente.copy(
                        titulo = current.titulo,
                        descripcion = current.descripcion,
                        categoria = current.categoria,
                        servicio = current.servicio,
                        evidenciaUri = current.evidenciaUri,
                        fechaEdicion = fechaActual
                    )
                    repository.actualizar(actualizada)
                    seleccionarSolicitud(actualizada)
                }
            }

            _uiState.update {
                SolicitudUiState(guardadoExitosamente = true)
            }
            resetForm()
            onSuccess()
        }
    }

    fun resetForm() {
        idEdicion = null
        _isEditing.value = false
        _uiState.value = SolicitudUiState()
    }
    
    fun clearQrProcessing() {
        _isProcessingQr.value = false
    }
}
